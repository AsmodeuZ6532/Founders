FOUNDERS LEAGUE — GitHub Pages

1. Распакуйте архив.
2. Загрузите index.html в корень репозитория GitHub (рядом с README.md).
3. В Settings → Pages выберите Deploy from a branch → main → /(root).
4. Сохраните настройки и дождитесь публикации.

Важно: локальные данные браузера не переносятся на GitHub автоматически. Перед заменой сайта экспортируйте резервную копию JSON.
